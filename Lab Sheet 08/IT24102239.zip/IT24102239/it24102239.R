setwd("C:\\Users\\it24102239\\Desktop\\IT24102239")
data<-read.table("Exercise - LaptopsWeights.txt" , header = TRUE")
fix(data)
attach(data)

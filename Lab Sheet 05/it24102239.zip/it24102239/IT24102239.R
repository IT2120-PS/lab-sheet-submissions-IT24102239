setwd("C:\\Users\\User\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\it24102239")

Delivery_Times<- read.table("Exercise - Lab 05.txt", header = TRUE, sep =",")

fix(data)
names(data)<-c("Age","Gender","Accommodation")

data$Gender<-factor(data$Gender,c(1,2),c("Male","Female"))
fix(data)
attach(data)

summary(data)

hist(Age,main="Histogram for Age")
abline(h=0)

X2.freq<-table(Gender)
X2.freq

barplot(X2.freq,beside = TRUE,main="Bar chart for Gender",xlab="Gender",ylab="Frequency")
abline(h=0)

boxplot(Age ~ Accommodation, data, 
        main = "Age Distribution by Accommodation Type", 
        xlab = "Accommodation (1=Home, 2=Boarded, 3=Lodging)", 
        ylab = "Age ",horizontal = TRUE)


